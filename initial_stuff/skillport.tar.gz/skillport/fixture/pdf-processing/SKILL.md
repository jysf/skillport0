---
name: pdf-processing
description: Extract text and tables from PDF files, fill forms, merge documents. Use when working with PDFs.
license: Apache-2.0
allowed-tools: [Bash, Read]
context: fork
effort: high
hooks:
  post-edit:
    script: scripts/format.sh
metadata:
  author: example-org
  version: "1.2"
compatible_agents: [claude-code, cursor]
---

# PDF Processing

Detailed instructions for the agent go here.

## Steps
1. Inspect the PDF.
2. Extract content.
